# bci_ml
Machine Learning and signal processing algorithms for brain computer interfaces
