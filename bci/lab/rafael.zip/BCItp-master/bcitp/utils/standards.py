import os

FONT_SIZE = 20

BUTTON_SIZE = (300, 50)

BUTTON_BOX_SIZE = (1, 0.4)


# DEFAULT PATHS
PATH_TO_SESSION = os.path.dirname(__file__) + '/../../data/session/'
