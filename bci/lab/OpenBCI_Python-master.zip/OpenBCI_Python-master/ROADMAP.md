# Roadmap

## OpenBCI Python

Provide a stable Python driver for all OpenBCI Biosensors

## Short term - what we're working on now

- WiFi

## Medium term

- Emotion detection
- Default set of instructions to send to the board on startup via command line
- Time sync with Cyton
