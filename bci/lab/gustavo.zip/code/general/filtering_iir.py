from scipy.signal import filtfilt, iirfilter

def filtering(X, fs=250, fl=8., fh=30., numtaps=5):

	#~ Nyquist frequency
    nf = fs / 2.

	#~ Get coefficients
    [b,a] = iirfilter(numtaps, [fl/nf, fh/nf])

	#~ Filter
    XF = filtfilt(b, a, X, axis=-1)
    
    return XF
