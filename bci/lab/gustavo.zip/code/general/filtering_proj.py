from numpy import asarray, convolve, dot, ones, zeros
from scipy.linalg import pinv

from sin_basis import make_basis

def filtering(X, fs=250., fl=8., fh=30., m=40):

    n_epochs = X.shape[0]
    n_channels = X.shape[1]
    W_Size = X.shape[2]
    
    B = make_basis(W_Size, m, fl/fs, fh/fs)
    G0 = dot(pinv(dot(B.T, B)), B.T)

    XF = asarray([dot(X[k,:,:], G0.T) for k in range(n_epochs)])
    
#    SMOOTH = 0
#    if SMOOTH:
#        v = ones((4)) / 4
#        XFC = zeros((n_epochs, n_channels, XF.shape[2] + len(v) - 1))
#        for i in range(n_epochs):
#            for j in range(n_channels):
#                XFC[i,j,:] = convolve(XF[i,j,:], v)
#        XF = XFC
                
    return XF
