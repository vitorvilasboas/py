#~ from numpy import ones
from scipy.signal import filtfilt, firwin

def filtering(X, fs=250, fl=8., fh=30., numtaps=5):

	#~ Nyquist frequency
    nf = fs / 2.

	#~ Get coefficients
    b = firwin(numtaps, [fl/nf, fh/nf])

	#~ Filter
    XF = filtfilt(b, [1], X, axis=-1)
    
    return XF
