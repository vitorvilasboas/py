def windowing(X, t_0, t_start, t_end, fs):

    W_Start = int((t_start - t_0) * fs)
    W_End = int((t_end - t_0) * fs)
    
    for i in range(2):
        for j in range(2):
            X[i][j] = X[i][j][:,:,W_Start:W_End]
            
    return X
