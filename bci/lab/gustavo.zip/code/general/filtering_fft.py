from numpy import concatenate, imag, real, zeros
from numpy.fft import fft

def filtering(X):

    fs = 250
    fl = 8.
    fh = 30.
    
    n_epochs = X.shape[0]
    n_channels = X.shape[1]
    W_Size = X.shape[2]
    
    FL = int(W_Size*fl/fs)
    FH = int(W_Size*fh/fs)
    FN = FH - FL
    XF = zeros((n_epochs, n_channels, 2*FN))
    for k in range(n_epochs):
        for l in range(n_channels):
            XFFT = fft(X[k,l,:])
            XREAL = real(XFFT)[FL:FH]
            XIMAG = imag(XFFT)[FL:FH]
            XF[k,l,:] = concatenate([XREAL, XIMAG])
    
    return XF
