def get_step(n_bins, n_bands, overlap):

	step = (n_bins / n_bands / 2) * 2
	size = step * overlap
	
	while True:
		last_end = (n_bands-1) * step + size
		if last_end <= n_bins:
			break
		step -= 2

	return step
