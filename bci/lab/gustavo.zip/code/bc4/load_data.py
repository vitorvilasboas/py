from numpy import dtype, fromfile, transpose

def load_data(SUBJECT, classes):

    folder = "/home/gustavo/bci/data/epoched"

    X = [[], []]
    set = ['T_', 'E_']

    for i in range(2):
        for j in range(2):
            path = folder + '/A0' + str(SUBJECT) + set[j] + str(classes[i]) + '.fdt'
            fid = open(path, 'rb')
            data = fromfile(fid, dtype('f'))
            data = data.reshape((72, 1000, 22))
            X[j].append(transpose(data, (0,2,1)))
    
    return X
    
if __name__ == "__main__":

    SUBJECT = 1
    classes = [1, 2]

    X = load_data(SUBJECT, classes)
    
#    X[train/validation set][classe]
#    X_Tset_classe1 = X[0][0]
#    X_Tset_classe2 = X[0][1]
#    X_Vset_classe1 = X[1][0]
#    X_Vset_classe2 = X[1][1]

    print type(X)
    print type(X[0])
    print type(X[0][0])
    print X[0][0].shape
