from sys import stdout

from numpy import arange, mean, set_printoptions, zeros
from time import time

#~ from sbcsp_mc_proj import get_acc
from sbcsp_mc_filt import get_acc
#~ from basic import get_acc
#~ from csp_lda_bc3 import get_acc


def evaluate(args):

	fl, fh, m, n_components, Clog, n_bands = args
	print '\n\nfl: ', fl
	print 'fh: ', fh
	print 'm: ', m
	print 'n_components: ', n_components
	print 'Clog: ', Clog
	print 'n_bands: ', n_bands

	subjectsT = arange(1,10)
	classesT = [[1,2], [1,3], [1,4], [2,3], [2,4], [3,4]]

	att = zeros((len(subjectsT),len(classesT)))
	i = 0
	j = 0

	for SUBJECT, i in zip(subjectsT, range(10)):
		for classes, j in zip(classesT, range(7)):
			
			t0 = time()
			
			try:
				acc_test = get_acc(SUBJECT, classes, args)
			except (KeyboardInterrupt, SystemExit):
				raise
				
			print('\nTime: ' + str(time() - t0))
			
			#~ except:
				#~ print 'ERROR !!!'
				#~ acc_test = 0
			att[i,j] = acc_test
			
			print(str(i*6 + j)),
			stdout.flush()
		
	print('\nMean test accuracy: ' + str(mean(att)*100))

	#~ print('\n\nAccuracy table: ' + str(mean(att)*100))
	#~ set_printoptions(precision=2)
	#~ print att.T*100

	#~ print '\nAccuracy by class combination'
	#~ print mean(att*100,axis=0)

	#~ print '\nAccuracy by subject'
	#~ print mean(att*100,axis=1)

	return 1 - mean(att)

if __name__ == "__main__":

	#~ Best results

	fl = 0
	fh = 51
	m = 100
	n_components = 6
	Clog = -4
	n_bands = 33

	numtaps = 3

	#~ fl = 0
	#~ fh = 58
	#~ m = 111
	#~ n_components = 2
	#~ Clog = -3
	#~ n_bands = 24

	#~ args = (fl, fh, m, n_components, Clog, n_bands)
	args = (fl, fh, numtaps, n_components, Clog, n_bands)

	evaluate(args)
