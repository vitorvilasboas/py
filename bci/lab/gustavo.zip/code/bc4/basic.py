from mne.decoding.csp import CSP
from numpy import concatenate, mean, ones, zeros
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sys import path
from time import time

path.append('/home/gustavo/bci/code/general')

from load_data import load_data
from windowing import windowing
from filtering_proj import filtering

def get_acc(subject, classes, n_components):

    X = load_data(subject, classes)
    
    X = windowing(X, 2, 2.5, 4.5, 250)
    
    ## Set data format for CSP
    
    XT = concatenate(X[0])
    XV = concatenate(X[1])
    y = concatenate([zeros(72), ones(72)])

    ## Filtering
    
    XT = filtering(XT)
    XV = filtering(XV)

    ## CSP

    csp = CSP(n_components=n_components)
    csp.fit(XT, y)
    XT_CSP = csp.transform(XT)
    XV_CSP = csp.transform(XV)

    ## LDA

    clf = LinearDiscriminantAnalysis()
    clf.fit(XT_CSP, y)
    acc_test = mean(clf.predict(XV_CSP) == y)

    return acc_test

if __name__ == "__main__":

    subject = 1
    classes = [1,4]
    
    n_components = 6
    
    t0 = time()
    acc_test = get_acc(subject, classes, n_components)
    print time()-t0
    
    print('Test accuracy: ' + str(acc_test*100))
